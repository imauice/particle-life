package com.particlelife.wallpaper;
import android.service.wallpaper.WallpaperService;import android.view.SurfaceHolder;import android.view.MotionEvent;import android.graphics.*;import android.os.Handler;import android.os.Looper;import android.content.SharedPreferences;import java.util.*;
public class BondWallpaperService extends WallpaperService {
 @Override public Engine onCreateEngine(){return new BondEngine();}
 class Particle {float x,y,vx,vy;int type,degree;Particle(float x,float y,int type){this.x=x;this.y=y;this.type=type;vx=(random.nextFloat()-.5f)*.5f;vy=(random.nextFloat()-.5f)*.5f;}}
 class Bond {int a,b;Bond(int a,int b){this.a=a;this.b=b;}}
 final Random random=new Random();final int[] colors={0xff5eead4,0xff60a5fa,0xfffbbf24};
 class BondEngine extends Engine {
 final Handler handler=new Handler(Looper.getMainLooper());final Paint paint=new Paint(3);final ArrayList<Particle> particles=new ArrayList<>();final ArrayList<Bond> bonds=new ArrayList<>();boolean visible=false;int width=1,height=1;float scale=1f;SharedPreferences prefs=getSharedPreferences("settings",MODE_PRIVATE);
 final Runnable frame=new Runnable(){public void run(){if(!visible)return;long start=android.os.SystemClock.uptimeMillis();simulate();draw();int fps=prefs.getInt("fps",30);handler.postDelayed(this,Math.max(1,1000/fps-(android.os.SystemClock.uptimeMillis()-start)));}};
 BondEngine(){setTouchEventsEnabled(true);}
 void add(float x,float y,int count){for(int i=0;i<count&&particles.size()<650;i++){float a=random.nextFloat()*6.283185f,r=(float)Math.sqrt(random.nextFloat())*45;particles.add(new Particle(clamp(x+(float)Math.cos(a)*r,5,width-5),clamp(y+(float)Math.sin(a)*r,5,height-5),random.nextInt(3)));}}
 void reset(){particles.clear();bonds.clear();int n=prefs.getInt("particles",420);int cols=3,rows=5;int groups=cols*rows;for(int k=0;k<groups;k++){int col=k%cols,row=k/cols;float cx=width*(col+.5f)/cols+(random.nextFloat()-.5f)*width*.09f;float cy=height*(row+.5f)/rows+(random.nextFloat()-.5f)*height*.06f;int count=n/groups+(k<n%groups?1:0);int start=particles.size();add(cx,cy,count);float angle=random.nextFloat()*6.283185f;float vx=(float)Math.cos(angle)*.28f,vy=(float)Math.sin(angle)*.28f;for(int i=start;i<particles.size();i++){particles.get(i).vx+=vx;particles.get(i).vy+=vy;}}}
 @Override public void onSurfaceChanged(SurfaceHolder holder,int format,int w,int h){super.onSurfaceChanged(holder,format,w,h);scale=Math.max(1f,Math.min(3f,w/400f));width=Math.max(1,Math.round(w/scale));height=Math.max(1,Math.round(h/scale));reset();}
 @Override public void onVisibilityChanged(boolean v){visible=v;handler.removeCallbacks(frame);if(v)handler.post(frame);}
 @Override public void onSurfaceDestroyed(SurfaceHolder h){visible=false;handler.removeCallbacks(frame);super.onSurfaceDestroyed(h);}
 @Override public void onDestroy(){visible=false;handler.removeCallbacks(frame);super.onDestroy();}
 @Override public void onTouchEvent(MotionEvent e){if(e.getAction()==MotionEvent.ACTION_DOWN)add(e.getX()/scale,e.getY()/scale,24);}
 int maxDegree(Particle p){return p.type==0?3:2;}
 float clamp(float a,float lo,float hi){return Math.max(lo,Math.min(hi,a));}
 void simulate(){int n=particles.size();float[] fx=new float[n],fy=new float[n];float noise=prefs.getInt("noise",20)/100f,bondChance=prefs.getInt("bond",70)/100f,strength=prefs.getInt("strength",65)/100f;
 for(int i=0;i<n;i++){fx[i]=(random.nextFloat()-.5f)*noise*.32f;fy[i]=(random.nextFloat()-.5f)*noise*.32f;}
 for(int k=bonds.size()-1;k>=0;k--){Bond bond=bonds.get(k);Particle a=particles.get(bond.a),b=particles.get(bond.b);float dx=b.x-a.x,dy=b.y-a.y,d=(float)Math.hypot(dx,dy);if(d>95){a.degree--;b.degree--;bonds.remove(k);continue;}d=Math.max(.001f,d);float f=(d-13)*(.006f+strength*.024f);fx[bond.a]+=f*dx/d;fy[bond.a]+=f*dy/d;fx[bond.b]-=f*dx/d;fy[bond.b]-=f*dy/d;}
 for(int i=0;i<n;i++){Particle a=particles.get(i);for(int j=i+1;j<n;j++){Particle b=particles.get(j);float dx=b.x-a.x,dy=b.y-a.y,d2=dx*dx+dy*dy;if(d2>1024||d2<.0001f)continue;float d=(float)Math.sqrt(d2),nx=dx/d,ny=dy/d;if(d<8){float f=(8-d)*.042f;fx[i]-=f*nx;fy[i]-=f*ny;fx[j]+=f*nx;fy[j]+=f*ny;}if(d<23&&a.degree<maxDegree(a)&&b.degree<maxDegree(b)&&bonds.size()<950&&random.nextFloat()<bondChance*.013f&&!connected(i,j)){bonds.add(new Bond(i,j));a.degree++;b.degree++;}}}
 for(int i=0;i<n;i++){Particle p=particles.get(i);p.vx=(p.vx+fx[i])*.94f;p.vy=(p.vy+fy[i])*.94f;float v=(float)Math.hypot(p.vx,p.vy);if(v>2){p.vx*=2/v;p.vy*=2/v;}p.x+=p.vx;p.y+=p.vy;if(p.x<4||p.x>width-4){p.vx*=-.8f;p.x=clamp(p.x,4,width-4);}if(p.y<4||p.y>height-4){p.vy*=-.8f;p.y=clamp(p.y,4,height-4);}}}
 boolean connected(int i,int j){for(Bond b:bonds)if(b.a==i&&b.b==j)return true;return false;}
 void draw(){Canvas c=null;try{c=getSurfaceHolder().lockCanvas();if(c==null)return;c.drawColor(0xff050b16);c.save();c.scale(scale,scale);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(1.15f);paint.setColor(0xb894d2f0);for(Bond b:bonds){Particle a=particles.get(b.a),d=particles.get(b.b);c.drawLine(a.x,a.y,d.x,d.y,paint);}paint.setStyle(Paint.Style.FILL);for(Particle p:particles){paint.setColor(colors[p.type]);c.drawCircle(p.x,p.y,2.65f,paint);}c.restore();}catch(Exception ignored){}finally{if(c!=null)try{getSurfaceHolder().unlockCanvasAndPost(c);}catch(Exception ignored){}}}
 }
}
